
<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <h1>Dashboard</h1>
            <div class="col-md-12 p-1">
                <div class="card mb-2">
                    <div class="card-body">
                        <form action="/admin/categories/add" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="name" placeholder="Tambahkan Kategori"
                                    required>
                                <button class="btn btn-primary" type="submit">Tambah</button>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </form>
                        <table class="table table-hover border">
                            <thead class="text-center">
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Kategori</th>
                                    <th scope="col">Jumlah Tulisan</th>
                                    <th scope="col" colspan="2">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">

                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php if(request('edit' . $category->id)): ?>
                                                <form action="/admin/categories/edit">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="input-group mb-3">
                                                        <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
                                                        <input type="text" class="form-control" name="name"
                                                            placeholder="Ubah Nama Kategori" value="<?php echo e($category->name); ?>"
                                                            required>
                                                        <button class="btn btn-primary" type="submit">Ubah</button>
                                                    </div>
                                                </form>
                                            <?php else: ?>
                                                <?php echo e($category->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($category->posts->count()); ?></td>
                                        <td class="text-end">
                                            <form action="/admin/categories">
                                                <button class="btn btn-warning" name="edit<?php echo e($category->id); ?>"
                                                    value="true"><i class="bi bi-pencil"></i></button>
                                            </form>
                                        </td>
                                        <td class="text-start">
                                            <form action="/admin/categories/delete">
                                                <button name="del_category" class="btn btn-danger"
                                                    value="<?php echo e($category->id); ?>"><i class="bi bi-trash-fill"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <h1 class="mt-1 mb-3"></h1>
                        <div class="mb-0">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/admin_categories.blade.php ENDPATH**/ ?>

<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-12 p-1">
                <div class="card mb-2">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Buat Tulisan</h5>
                        <small class="text-muted">
                            <a class="mb-2"><?php echo e(auth()->user()->name); ?></a> -
                        </small>
                        <small class="text-muted"><?php echo e(date('d M Y')); ?></small>
                        <form action="/user/create/post" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                            <div class="input-group mb-2 mt-2">
                                <input class="form-control form-control-lg <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="text" name="judul" placeholder="Judul Tulisan" required />
                                <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-group mb-3">
                                <label class="input-group-text">Kategori</label>
                                <select class="form-select" name="category_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <input id="body" type="hidden" name="body">
                                <trix-editor input="body"></trix-editor>
                            </div>
                            <div>
                                <button class="btn btn-primary mt-2" type="submit">Buat Tulisan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('trix-file-accept', function(e) {
            e.preventDefault();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/post_create.blade.php ENDPATH**/ ?>
<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand text-center" href="/admin">
            <span class="align-middle">Admin | FDM</span>
        </a>

        <ul class="sidebar-nav">
            <li class="sidebar-header">
                Menu
            </li>

            <li class="sidebar-item <?php echo e($title === 'Dashboard' ? 'active' : ''); ?>">
                <a class="sidebar-link" href="/admin">
                    <i class="bi bi-pie-chart fs-5 align-middle"></i><span class="align-middle">Dashboard</span>
                </a>
            </li>

            <li class="sidebar-item <?php echo e($title === 'Kategori' ? 'active' : ''); ?>">
                <a class="sidebar-link" href="/admin/categories">
                    <i class="bi bi-tags fs-5 align-middle"></i><span class="align-middle">Kategori</span>
                </a>
            </li>

            <li class="sidebar-header">
                Forum
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link" href="/home">
                    <i class="bi bi-people fs-5 align-middle"></i><span class="align-middle">Go Forum</span>
                </a>
            </li>
        </ul>

        
    </div>
</nav>
<?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/partials/admin_sidebar.blade.php ENDPATH**/ ?>
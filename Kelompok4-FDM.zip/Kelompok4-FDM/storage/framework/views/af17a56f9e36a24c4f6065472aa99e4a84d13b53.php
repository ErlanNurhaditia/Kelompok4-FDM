
<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-4 p-1">
                <div class="card mb-2">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Profile Details</h5>
                    </div>
                    <div class="card-body text-center">
                        <img src="/img/avatars/blank.png" alt="Christina Mason" class="img-fluid rounded-circle mb-2"
                            width="128" height="128" />
                        <h5 class="card-title mb-0"><?php echo e($users->name); ?></h5>
                        <div class="text-muted mb-2"><?php echo e($users->username); ?></div>
                        <div>
                            <a class="btn btn-primary btn-sm" href="#"><i class="bi bi-pencil"></i>
                                <?php echo e(count($users->posts)); ?> Tulisan</a>
                            <a class="btn btn-primary btn-sm" href="#"><i class="bi bi-chat-dots"></i>
                                <?php echo e(count($users->comments)); ?> Tanggapan</a>
                        </div>
                        <?php if($users->username == auth()->user()->username): ?>
                            <hr class="my-0 mt-2" />
                            <a class="btn btn-outline-primary btn-sm w-100 mt-2" href="/profile/user/edit">
                                Edit Profile</a>
                            <a class="btn btn-outline-primary btn-sm w-100 mt-2" href="/user/create/post">
                                Buat Tulisan</a>
                        <?php endif; ?>
                    </div>
                </div>


            </div>
            <div class="col-md-8 p-1">
                <?php if($posts->count()): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-2">
                            <div class="card-body h-100">
                                <div class="d-flex align-items-start">
                                    <img src="/img/avatars/blank.png" width="36" height="36"
                                        class="rounded-circle me-2" alt="">
                                    <div class="flex-grow-1">
                                        <small class="float-end text-navy"><?php echo e($post->created_at->diffForHumans()); ?></small>
                                        <strong>
                                            <a class="text-dark" href="/post/<?php echo e($post->id); ?>"><?php echo e($post->judul); ?></a>
                                        </strong>
                                        <br>
                                        <small class="text-muted"><a href="#"><?php echo e($post->user->name); ?></a> - </small>
                                        <small class="text-muted"><?php echo e($post->created_at->format('d M Y H:i')); ?> WIB -
                                        </small>
                                        <small><a href="/categories/<?php echo e($post->category->id); ?>"
                                                class="text-primary"><?php echo e($post->category->name); ?></a></small>

                                        <div class="text-muted mt-1 text-justify">
                                            <?php echo $post->body; ?>

                                        </div>

                                        
                                        <a href="#" class="btn btn-sm btn-primary mt-1">
                                            <i class="bi bi-chat-dots"></i>
                                            <?php echo e(count($post->comments)); ?> Tanggapan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if($users->username == auth()->user()->username): ?>
                        <div class="card mb-2">
                            <div class="card-body h-100">
                                <a class="btn btn-primary btn-sm w-100 mt-2" href="/user/create/post">
                                    Buat Tulisan</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card mb-2">
                            <div class="card-body h-100">
                                Pengguna belum membuat tulisan
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/profile.blade.php ENDPATH**/ ?>
<div class="container-fluid">
    <div class="row text-muted">
        <div class="col-6 text-start">
            
        </div>
        <div class="col-6 text-end">
            
        </div>
    </div>
</div>
<?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/partials/footer.blade.php ENDPATH**/ ?>
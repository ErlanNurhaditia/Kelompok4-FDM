
<?php $__env->startSection('body'); ?>
    <main class="d-flex w-100">
        <div class="container d-flex flex-column">
            <div class="row vh-100">
                <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                    <div class="d-table-cell align-middle">

                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-warning alert-dismissible fade show text-center fixed-top" role="alert">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <?php if(session()->has('loginError')): ?>
                            <div class="alert alert-danger alert-dismissible fade show text-center fixed-top"
                                role="alert">
                                <?php echo e(session('loginError')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <div class="card">
                            <div class="card-body">
                                <div class="m-sm-4">
                                    <div class="text-center">
                                        <div class="text-center mt-4">
                                            <h3>Forum Diskusi Mahasiswa Fakultas Teknologi Informasi</h3>
                                            <h5 class="text-muted">Universitas Sebelas April</h5>
                                        </div>
                                        <img src="/img/logos/unsap2.png" class="img-fluid rounded-circle mb-2" width="132"
                                            height="132" />
                                    </div>
                                    <form action="/login/auth" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label class="form-label">Username</label>
                                            <input
                                                class="form-control form-control-lg <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                type="text" name="username" placeholder="Masukkan username" required
                                                value="<?php echo e(old('username')); ?>" />
                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Password</label>
                                            <div class="input-group mb-3">
                                                <input
                                                    class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    type="password" name="password" id="password_form"
                                                    placeholder="Masukkan password" required />

                                                <button id="btnShow" class="btn btn-outline-secondary border-1"
                                                    name="look" type="button" value="true" onclick="showPassword()"><i
                                                        id="btnIcon" class="bi bi-eye"></i>
                                                </button>
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                            </div>
                                        </div>
                                        
                                        <div class="text-center mt-3">
                                            <button type="submit" class="btn btn-lg btn-secondary w-100 mb-2">Masuk</button>
                                            <a href="/register" class="btn btn-lg btn-outline-secondary w-100">Daftar</a>
                                            <!-- <button type="submit" class="btn btn-lg btn-primary">Sign in</button> -->
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/app.js"></script>
    <script>
        function showPassword() {
            var icon = document.getElementById('btnIcon');

            if (icon.className == "bi bi-eye") {
                document.getElementById('password_form').setAttribute("type", "text");
                icon.className = "bi bi-eye-slash";
            } else {
                document.getElementById('password_form').setAttribute("type", "password");
                icon.className = "bi bi-eye";
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\Kelompok4-FDM\resources\views/login.blade.php ENDPATH**/ ?>
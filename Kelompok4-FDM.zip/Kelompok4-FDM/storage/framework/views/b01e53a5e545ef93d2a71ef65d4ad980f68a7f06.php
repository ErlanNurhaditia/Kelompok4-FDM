
<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-12 p-0">
                <form action="/home">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="search" placeholder="Cari tulisan..."
                            value=<?php echo e(request('search')); ?>>
                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
                    </div>
                </form>
                <?php if($posts->count()): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-1">
                            <div class="card-body h-100">
                                <div class="d-flex align-items-start">
                                    <img src="/img/avatars/blank.png" width="36" height="36"
                                        class="rounded-circle me-2" alt="">
                                    <div class="flex-grow-1">
                                        <small class="float-end text-navy"><?php echo e($post->created_at->diffForHumans()); ?></small>
                                        <strong>
                                            <a class="text-dark" href="/post/<?php echo e($post->id); ?>"><?php echo e($post->judul); ?></a>
                                        </strong>
                                        <br>
                                        <small class="text-muted">
                                            <a href="/profile/<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a> -
                                        </small>
                                        <small class="text-muted"><?php echo e($post->created_at->format('d M Y H:i')); ?> WIB -
                                        </small>
                                        <small><a href="/categories/<?php echo e($post->category->id); ?>"
                                                class="text-warning"><?php echo e($post->category->name); ?></a></small>

                                        <div class="text-muted mt-1 text-justify">
                                            <?php echo $post->body; ?>

                                        </div>

                                        
                                        <a href="/post/<?php echo e($post->id); ?>" class="btn btn-sm btn-secondary mt-1">
                                            <i class="bi bi-chat-dots"></i>
                                            <?php echo e(count($post->comments)); ?> Tanggapan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($posts->links()); ?>

                    </div>
                <?php else: ?>
                    <div class="card mb-2">
                        <div class="card-body h-100">
                            Data Kosong
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-12 p-0">
                <div class="card mb-2">
                    <div class="card-header">
                        <h3 class="mb-3">Kategori</h3>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <h4><a href="categories/<?php echo e($category['id']); ?>"><?php echo e($category->name); ?>

                                            (<?php echo e(count($category->posts)); ?>)
                                        </a>
                                    </h4>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/categories.blade.php ENDPATH**/ ?>

<?php $__env->startSection('contents'); ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-12 p-1">
                <div class="card mb-2">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Profile Details</h5>
                    </div>
                    <div class="card-body text-center">
                        <img src="/img/avatars/blank.png" alt="Christina Mason" class="img-fluid rounded-circle" width="128"
                            height="128" />
                        <p class="fs-5 mt-2">Untuk saat ini foto profile belum bisa diubah</p>
                    </div>
                    <div class="card-body">
                        <hr class="my-0" />
                        <form action="/edit_profile" method="POST">
                            <div class="mb-2">
                                <label class="form-label mt-2">Username :</label>
                                <div class="form-control-lg p-0"><?php echo e($users->username); ?></div>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Nama Lengkap :</label>
                                <input class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="text" name="name" placeholder="Masukkan nama lengkap" required
                                    value="<?php echo e($users->name); ?>" />
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-primary mt-2" type="submit">Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\forum\LARAVEL8-Informatics-Forum\resources\views/edit_profile.blade.php ENDPATH**/ ?>